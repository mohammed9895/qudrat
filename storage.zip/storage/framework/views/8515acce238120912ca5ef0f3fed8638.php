<!-- Header -->
<nav class="nav_area">
    <div class="px-10">
        <div class="flex flex-wrap items-center justify-between mx-auto p-4">
            <a href="/" class="flex items-center space-x-3">
                <img src="<?php echo e(asset('assets/images/logo.svg')); ?>" width="150" alt="" class="">
            </a>

            <div class="hidden w-full md:block md:w-auto" id="navbar-default">
                <ul class="font-medium flex flex-col p-4 md:px-7 mt-4 border border-gray-100 md:rounded-full bg-gray-50 md:flex-row md:space-x-4 rtl:md:space-x-reverse md:mt-0 md:border-0 md:bg-white md:shadow-default">
                    <li>
                        <a href="/" class="nav_link <?php echo e(request()->path() == '/' ? 'active' : ''); ?>"
                           aria-current="page"><?php echo e(__('general.navigation.home')); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('about.index')); ?>"
                           class="nav_link <?php echo e(request()->path() == 'about' ? 'active' : ''); ?>"><?php echo e(__('general.navigation.about')); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('digital-library.index')); ?>"
                           class="nav_link <?php echo e(request()->path() == 'digital-library' ? 'active' : ''); ?>"><?php echo e(__('general.navigation.digital-library')); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('future-skills.index')); ?>"
                           class="nav_link <?php echo e(request()->path() == 'future-skills' ? 'active' : ''); ?>"><?php echo e(__('general.navigation.future-skills')); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('media-center.index')); ?>"
                           class="nav_link <?php echo e(request()->path() == 'media-center' ? 'active' : ''); ?>"><?php echo e(__('general.navigation.media-center')); ?></a>
                    </li>
                    <li>
                        <button id="dropdownNavbarLink" data-dropdown-toggle="dropdownNavbar"
                                class="flex items-center justify-between w-full <?php echo e(request()->path() == 'social-window' ? 'active' : ''); ?> py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-brand-blue md:p-0 md:w-auto dark:text-white md:dark:hover:text-blue-500 dark:focus:text-white dark:border-gray-700 dark:hover:bg-gray-700 md:dark:hover:bg-transparent">
                            <?php echo e(__('general.navigation.social-window')); ?>

                            <svg class="w-2.5 h-2.5 ms-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                 fill="none" viewBox="0 0 10 6">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                      stroke-width="2" d="m1 1 4 4 4-4"/>
                            </svg>
                        </button>
                        <!-- Dropdown menu -->
                        <div id="dropdownNavbar"
                             class="z-10 hidden font-normal bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700 dark:divide-gray-600">
                            <ul class="py-2 text-sm text-gray-700 dark:text-gray-400"
                                aria-labelledby="dropdownLargeButton">
                                <li>
                                    <a href="<?php echo e(route('social-window.index')); ?>"
                                       class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">
                                        <?php echo e(__('general.navigation.profiles')); ?>

                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('social-window.experts')); ?>"
                                       class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">
                                        <?php echo e(__('general.navigation.experts')); ?>

                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('jobs.index')); ?>"
                                       class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">
                                        <?php echo e(__('general.navigation.jobs')); ?>

                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('works.index')); ?>"
                                       class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">
                                        <?php echo e(__('general.navigation.works')); ?>

                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <button id="dropdownNavbarLink" data-dropdown-toggle="dropdownNavbar-oman"
                                class="flex items-center justify-between <?php echo e(request()->path() == 'social-window/' ? 'active' : ''); ?> w-full py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-brand-blue md:p-0 md:w-auto dark:text-white md:dark:hover:text-blue-500 dark:focus:text-white dark:border-gray-700 dark:hover:bg-gray-700 md:dark:hover:bg-transparent">
                            <?php echo e(__('general.navigation.oman-scientists')); ?>

                            <svg class="w-2.5 h-2.5 ms-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                 fill="none" viewBox="0 0 10 6">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                      stroke-width="2" d="m1 1 4 4 4-4"/>
                            </svg>
                        </button>
                        <!-- Dropdown menu -->
                        <div id="dropdownNavbar-oman"
                             class="z-10 hidden font-normal bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700 dark:divide-gray-600">
                            <ul class="py-2 text-sm text-gray-700 dark:text-gray-400"
                                aria-labelledby="dropdownLargeButton">
                                <li>
                                    <a href="<?php echo e(route('social-window.researchers')); ?>"
                                       class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">
                                        <?php echo e(__('general.navigation.researchers')); ?>

                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('social-window.innovators')); ?>"
                                       class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">
                                        <?php echo e(__('general.navigation.innovators')); ?>

                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <a href="<?php echo e(route('contact.index')); ?>"
                           class="nav_link <?php echo e(request()->path() == 'contact' ? 'active' : ''); ?>"><?php echo e(__('general.navigation.contact-us')); ?></a>
                    </li>
                </ul>
            </div>


            <?php if(auth()->guard()->guest()): ?>
                <div class="nav_btn items-center hidden lg:flex">
                    <?php if(session()->get('lang') == 'ar'): ?>
                        <a href="<?php echo e(route('locale', 'en')); ?>"
                           class="w-[50px] h-[50px] flex items-center rtl:ml-1 justify-center rounded-full border border-brand-blue text-head-color font-medium hover:bg-brand-blue hover:text-white">EN</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('locale', 'ar')); ?>"
                           class="w-[50px] h-[50px] flex items-center justify-center rounded-full border border-brand-blue text-head-color font-medium hover:bg-brand-blue hover:text-white">ع</a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('filament.user.auth.register')); ?>"
                       class="px-8 py-3 rounded-full border border-brand-blue text-head-color font-medium hover:bg-brand-blue hover:text-white">
                        <?php echo e(__('general.navigation.register')); ?>

                    </a>
                    <a href="<?php echo e(route('filament.user.auth.login')); ?>"
                       class="px-8 py-3 rounded-full border bg-brand-blue text-head-color font-medium hover:bg-primary-1 text-white flex items-center justify-center">
                        <?php echo e(__('general.navigation.login')); ?>

                        <img src="<?php echo e(asset('assets/images/arrow-right.svg')); ?>" class="ml-2 rtl:mr-2 rtl:ml-0" alt="">
                    </a>
                </div>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <div class="flex items-center justify-center md:order-2 space-x-3 md:space-x-3 rtl:space-x-reverse">
                    <?php if(session()->get('lang') == 'ar'): ?>
                        <a href="<?php echo e(route('locale', 'en')); ?>"
                           class="w-[50px] h-[50px] flex items-center justify-center rounded-full border border-brand-blue text-head-color font-medium hover:bg-brand-blue hover:text-white">EN</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('locale', 'ar')); ?>"
                           class="w-[50px] h-[50px] flex items-center justify-center rounded-full border border-brand-blue text-head-color font-medium hover:bg-brand-blue hover:text-white">AR</a>
                    <?php endif; ?>
                    <button type="button"
                            class="flex text-sm bg-gray-800 rounded-full md:me-0 focus:ring-4 focus:ring-gray-300 dark:focus:ring-gray-600"
                            id="user-menu-button" aria-expanded="false" data-dropdown-toggle="user-dropdown"
                            data-dropdown-placement="bottom">
                        <span class="sr-only">Open user menu</span>
                        <img class="w-[50px] h-[50px] rounded-full" src="/storage/<?php echo e(auth()->user()->profile->avatar); ?>"
                             alt="user photo">
                    </button>
                    <!-- Dropdown menu -->
                    <div
                        class="z-50 hidden my-4 text-base list-none bg-white divide-y divide-gray-100 rounded-lg shadow dark:bg-gray-700 dark:divide-gray-600"
                        id="user-dropdown">
                        <div class="px-4 py-3">
                            <span class="block text-sm text-gray-900 dark:text-white"><?php echo e(auth()->user()->name); ?></span>
                            <span
                                class="block text-sm  text-gray-500 truncate dark:text-gray-400"><?php echo e(auth()->user()->email); ?></span>
                        </div>
                        <ul class="py-2" aria-labelledby="user-menu-button">
                            <li>
                                <a href="<?php echo e(route('filament.user.pages.dashboard')); ?>"
                                   class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white"><?php echo e(__('general.navigation.dashboard')); ?></a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('filament.user.auth.logout')); ?>"
                                   class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white"><?php echo e(__('general.navigation.sign-out')); ?></a>
                            </li>
                        </ul>
                    </div>
                    <button data-collapse-toggle="navbar-user" type="button"
                            class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600"
                            aria-controls="navbar-user" aria-expanded="false">
                        <span class="sr-only">Open main menu</span>
                        <svg class="w-7 h-7" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                             viewBox="0 0 17 14">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M1 1h15M1 7h15M1 13h15"/>
                        </svg>
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>
<!-- Header -->
<?php /**PATH /Users/mohammedhamad/Sites/qudrat/resources/views/components/partials/nav.blade.php ENDPATH**/ ?>