<div>
    <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?>
    <!-- Banner -->
    <div class="bg-brand-blue/30 pt-24 md:pt-10 pb-5">
        <div class="container">
            <div class="flex items-center justify-between gap-4 flex-wrap md:flex-nowrap">
                <div class="w-full md:w-6/12">
                    <?php if (isset($component)) { $__componentOriginal2a6105802b9b852c0c1141b63006edde = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a6105802b9b852c0c1141b63006edde = $attributes; } ?>
<?php $component = WireUi\Breadcrumbs\Components\Tallstack::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Breadcrumbs\Components\Tallstack::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a6105802b9b852c0c1141b63006edde)): ?>
<?php $attributes = $__attributesOriginal2a6105802b9b852c0c1141b63006edde; ?>
<?php unset($__attributesOriginal2a6105802b9b852c0c1141b63006edde); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a6105802b9b852c0c1141b63006edde)): ?>
<?php $component = $__componentOriginal2a6105802b9b852c0c1141b63006edde; ?>
<?php unset($__componentOriginal2a6105802b9b852c0c1141b63006edde); ?>
<?php endif; ?>
                    <h2 class="text-4xl sm:text-5xl font-semibold mb-3"><?php echo e(__('general.feedback.main-title')); ?></h2>
                </div>
                <div class="w-6/12">
                    <div class="text-end">
                        <img src="assets/images/banner_1.png" alt="images" class="hidden md:block">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Banner -->

    <!-- Card & Siderbar -->
    <div class="pt-24 pb-12">
        <div class="container">
            <form wire:submit="create">
                <?php echo e($this->form); ?>


                <button type="submit">
                    Submit
                </button>
            </form>

            <?php if (isset($component)) { $__componentOriginal028e05680f6c5b1e293abd7fbe5f9758 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-actions::components.modals','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-actions::modals'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758)): ?>
<?php $attributes = $__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758; ?>
<?php unset($__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal028e05680f6c5b1e293abd7fbe5f9758)): ?>
<?php $component = $__componentOriginal028e05680f6c5b1e293abd7fbe5f9758; ?>
<?php unset($__componentOriginal028e05680f6c5b1e293abd7fbe5f9758); ?>
<?php endif; ?>
        </div>
    </div>
    <!-- /Card & Siderbar -->
    <?php echo \Filament\Support\Facades\FilamentAsset::renderScripts() ?>
</div>
<?php /**PATH /Users/mohammedhamad/Sites/qudrat/resources/views/livewire/frontend/feed-back/index.blade.php ENDPATH**/ ?>