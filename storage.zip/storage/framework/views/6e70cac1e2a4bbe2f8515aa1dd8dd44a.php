<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['layout', 'page' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['layout', 'page' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    use SolutionForest\FilamentCms\Dto\CmsPageData;use SolutionForest\FilamentCms\Facades\FilamentCms;

    /** @var array $layout */
    /** @var ?CmsPageData $page */

    $theme = FilamentCms::getCurrentTheme();
?>

<?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => 'filament-cms::'.e($theme).'.page'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['layout' => $layout]); ?>


    <div
        class=" mt-32 py-48 container flex flex-col items-center justify-center relative overflow-hidden bg-brand-blue rounded-lg">
        <div class="w-full h-full absolute top-0 invert z-10" style="background-image: url('https://yc.om/images/rouneded-lg.webp'); background-position: top center;
    background-repeat: no-repeat;
    background-size: 102% auto;" bis_skin_checked="1"></div>
        <div class="z-30 flex flex-col w-full items-center justify-center">
            <h1 class="prose prose-strong:text-brand-yellow text-white text-5xl text-center leading-3"><?php echo $page->data['main_title']; ?></h1>
            <form action="" class="mt-14 w-3/4 md:w-1/2 relative">
                <input type="text" class="w-full border-none px-5 py-4 rounded-full"
                       placeholder="<?php echo e(__('general.hero.hero-search')); ?>">
                <button type="submit"
                        class="absolute w-10 h-10 flex items-center justify-center rounded-full right-2 rtl:right-auto rtl:left-2 top-2 bg-brand-blue text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                         stroke="currentColor" class="size-6">
                        <path stroke-linecap="round" stroke-linejoin="round"
                              d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z"/>
                    </svg>
                </button>
            </form>
        </div>
        <div class="absolute left-60 top-4 z-30" bis_skin_checked="1">
            <div class="bg-brand-green shadow-2xl rounded-lg relative px-5 pt-10 "
                 bis_skin_checked="1">
                <div class="p-3 text-white absolute bottom-1 left-1 rtl:left-auto rtl:right-1 z-10"
                     bis_skin_checked="1">
                    <h3 class="font-bold text-md text-white">عبدالعزيز الريامي</h3>
                    <h4 class="text-white">مسوق</h4>
                </div>
                <div class="flex justify-center" bis_skin_checked="1">
                    <img src="https://yc.om/images/aziz.png" class="w-32 " alt="">
                </div>
            </div>
        </div>
        <div class="absolute left-10 top-32 z-30" bis_skin_checked="1">
            <div class="bg-brand-yellow shadow-lg rounded-lg relative px-5 pt-10 "
                 bis_skin_checked="1">
                <div class="p-3 text-white absolute bottom-1 left-1 rtl:left-auto rtl:right-1 z-10"
                     bis_skin_checked="1">
                    <h3 class="font-bold text-md text-white">صفاء النبهاني</h3>
                    <h4 class="text-white">مهندسة معمارية</h4>
                </div>
                <div class="flex justify-center" bis_skin_checked="1">
                    <img src="https://yc.om/images/safa.png" class="w-32 " alt="">
                </div>
            </div>
        </div>
        <div class="absolute left-32 bottom-10 z-30" bis_skin_checked="1">
            <div class="bg-brand-red shadow-lg rounded-lg relative px-5 pt-10 "
                 bis_skin_checked="1">
                <div class="p-3 text-white absolute bottom-1 left-1 rtl:left-auto rtl:right-1 z-10"
                     bis_skin_checked="1">
                    <h3 class="font-bold text-md text-white">مريم الكندي</h3>
                    <h4 class="text-white">مهندسة معمارية</h4>
                </div>
                <div class="flex justify-center" bis_skin_checked="1">
                    <img src="https://yc.om/images/maryam.png" class="w-32 " alt="">
                </div>
            </div>
        </div>
        <div class="absolute right-60 top-4 z-30" bis_skin_checked="1">
            <div class="bg-brand-yellow shadow-lg rounded-lg relative px-5 pt-10 "
                 bis_skin_checked="1">
                <div class="p-3 text-white absolute bottom-1 left-1 rtl:left-auto rtl:right-1 z-10"
                     bis_skin_checked="1">
                    <h3 class="font-bold text-md text-white">مريم الكندي</h3>
                    <h4 class="text-white">مهندسة معمارية</h4>
                </div>
                <div class="flex justify-center" bis_skin_checked="1">
                    <img src="https://yc.om/images/audi.png" class="w-32 " alt="">
                </div>
            </div>
        </div>
        <div class="absolute right-10 top-32 z-30" bis_skin_checked="1">
            <div class="bg-brand-green shadow-lg rounded-lg relative px-5 pt-10 "
                 bis_skin_checked="1">
                <div class="p-3 text-white absolute bottom-1 left-1 rtl:left-auto rtl:right-1 z-10"
                     bis_skin_checked="1">
                    <h3 class="font-bold text-md text-white">وجدان الفارسي</h3>
                    <h4 class="text-white">مهندسة معمارية</h4>
                </div>
                <div class="flex justify-center" bis_skin_checked="1">
                    <img src="https://yc.om/images/wijdan.png" class="w-32 " alt="">
                </div>
            </div>
        </div>
        <div class="absolute right-32 bottom-10 z-30" bis_skin_checked="1">
            <div class="bg-brand-gray shadow-lg rounded-lg relative px-5 pt-10 "
                 bis_skin_checked="1">
                <div class="p-3 text-white absolute bottom-1 left-1 rtl:left-auto rtl:right-1 z-10"
                     bis_skin_checked="1">
                    <h3 class="font-bold text-md text-white">وجدان الفارسي</h3>
                    <h4 class="text-white">مهندسة معمارية</h4>
                </div>
                <div class="flex justify-center" bis_skin_checked="1">
                    <img src="https://yc.om/images/bushra.png" class="w-32 " alt="">
                </div>
            </div>
        </div>
    </div>


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


    <!-- Logo -->
    <div class="pt-24 pb-12">
        <div class="text-center">
            <h5 class="font-semibold text-xl mb-5"><?php echo e($page->data['sponsors_title']); ?></h5>
        </div>
        <div class="px-10">
            <div class="flex items-center justify-center 2xl:justify-between gap-5 flex-wrap">
                <?php $__currentLoopData = $page->data['sponsors_images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="/storage/<?php echo e($sponsor); ?>" alt="images"
                         class="opacity-50 hover:opacity-100 transition"/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- /Logo -->


    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.home.profiles', ['profilesPerCategory' => 10,'title' => $page->data['talent_title'],'description' => $page->data['talent_description'],'profiles_per_category' => 10]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2951322651-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>


    <!-- About -->
    <div class="bg-white py-24">
        <div class="container">
            <div class="flex items-center justify-between gap-4 flex-wrap lg:flex-nowrap">
                <div class="w-full lg:w-6/12 relative">
                    <img src="/storage/<?php echo e($page->data['about_image']); ?>" alt="images" class="">
                    <img src="<?php echo e(asset('assets/images/red-shape.svg')); ?>"
                         class="w-20 absolute top-32 -right-10"
                         alt="">

                    <img src="<?php echo e(asset('assets/images/yellow-shape.svg')); ?>"
                         class="w-20 absolute -top-10 left-2 rotate-120 "
                         alt="">

                    <img src="<?php echo e(asset('assets/images/green-shape.svg')); ?>"
                         class="w-20 absolute bottom-64 left-2 rotate-45 "
                         alt="">

                    <img src="<?php echo e(asset('assets/images/gray-shape.svg')); ?>"
                         class="w-10 absolute -bottom-10 left-3/4 rotate-45"
                         alt="">
                </div>
                <div class="w-full lg:w-6/12 xl:w-5/12">
                    <h2 class="text-4xl sm:text-5xl font-semibold mb-3"><?php echo e($page->data['about_title']); ?></h2>
                    <p class="text-b-color mb-10"><?php echo e($page->data['about_description']); ?></p>
                    <div class="flex flex-col gap-8">
                        <?php $__currentLoopData = $page->data['about_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex gap-5 items-center">
                                <div
                                    class="shrink-0 bg-gradient-to-t from-brand-blue/30 to-transparent w-24 h-24 rounded-full flex justify-center items-center">
                                    <img src="/storage/<?php echo e($item['image']); ?>" alt="images" class="w-14">
                                </div>
                                <div>
                                    <h5 class="text-2xl font-medium mb-3"><?php echo e($item['title']); ?></h5>
                                    <p><?php echo e($item['description']); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /About -->


    <!-- Step -->
    <div class="pt-24 pb-12">
        <div class="container">
            <div class="flex items-center justify-between gap-4 flex-wrap">
                <div class="w-full xl:w-5/12">
                    <h2 class="text-4xl sm:text-5xl font-semibold mb-3"><?php echo e($page->data['steps_title']); ?></h2>
                    <p class="text-b-color mb-10"><?php echo e($page->data['steps_description']); ?></p>
                    <a href="<?php echo e($page->data['steps_button_url']); ?>"
                       class="px-8 py-3 rounded-full text-head-color font-medium bg-brand-red text-white inline-flex items-center gap-2"><?php echo e($page->data['steps_button_text']); ?>

                        <span><svg width="12" height="10" viewBox="0 0 12 10" fill="none"
                                   xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M0.991646 9.27349C0.991646 9.27349 6.25866 4.77968 11.0089 0.726747M11.0089 0.726747C7.57736 3.65456 3.95259 0.688952 3.95259 0.688952M11.0089 0.726747C7.57736 3.65456 9.9353 7.70104 9.9353 7.70104"
                            stroke="white" stroke-width="1.5"/>
                        </svg>
                        </span></a>
                </div>
                <div class="w-full xl:w-6/12">
                    <div class="grid grid-cols-12 gap-6">
                        <?php $__currentLoopData = $page->data['steps']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-span-12 md:col-span-6">
                                <div
                                    class="bg-transparent border-[3px] border-white rounded-xl p-5 hover:bg-white transition-all relative h-full">
                                    <h4 class="text-5xl font-bold text-brand-red text-opacity-25 absolute top-1 end-1">
                                        <?php echo e($step['number']); ?></h4>
                                    <img src="/storage/<?php echo e($step['image']); ?>" alt="images" class="w-20 mb-3">
                                    <h6 class="text-xl font-semibold mb-2"><?php echo e($step['title']); ?></h6>
                                    <p class="mb-4"><?php echo e($step['description']); ?></p>
                                    <div class="flex justify-between">
                                        <span
                                            class="inline-block w-[36px] h-[36px] bg-brand-red bg-opacity-50 rounded-full flex items-center justify-center">
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M0.718519 15.3351C0.718519 15.3351 7.25344 8.79999 14.7269 1.32652M14.7269 1.32652C9.32811 6.72532 2.8156 2.20588 2.8156 2.20588M14.7269 1.32652C9.32811 6.72532 13.8475 13.2378 13.8475 13.2378"
                                                stroke="white" stroke-width="1.42857"></path>
                                        </svg>
                                    </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Step -->


    <!-- Feedback -->
    <div class="py-12">
        <div class="container">
            <div class="rounded-lg relative">
                <img src="/storage/<?php echo e($page->data['testimonials_image']); ?>" alt="images" class="min-h-[280px] w-full">
                <div class="pt-8 sm:pt-16 lg:pt-24 w-full flex justify-center absolute start-0 top-0">
                    <div class="xl:w-7/12 text-center px-6 xl:px-0">
                        <h2 class="text-white text-4xl sm:text-5xl font-semibold mb-3"><?php echo e($page->data['testimonials_title']); ?></h2>
                    </div>
                </div>
            </div>
            <div class="sm:px-8 mt-10 lg:mt-[-70px] 2xl:mt-[-150px]">
                <div class="feedback_slider swiper pb-4">
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $page->data['testimonials']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">
                                <div class="bg-white p-7 rounded-2xl shadow-default">
                                    <p class="mb-4"><?php echo e($testimonial['description']); ?></p>
                                    <div class="flex items-center gap-4">
                                        <div class="shrink-0">
                                            <img src="/storage/<?php echo e($testimonial['image']); ?>" alt="image" class="">
                                        </div>
                                        <div>
                                            <h6 class="text-sm font-semibold"><?php echo e($testimonial['name']); ?></h6>
                                            <p class="text-xs"><?php echo e($testimonial['position']); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="flex items-center justify-center gap-4 mt-6">
                        <div
                            class="swiper_nav_prev w-[48px] h-[48px] bg-white hover:bg-primary-1 rounded-full flex items-center justify-center">
                            <span>
                                <svg width="15" height="15" viewBox="0 0 15 15" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M14.3344 14.0526C14.3344 14.0526 8.06084 7.77895 0.886306 0.604417M0.886306 0.604417C6.06915 5.78726 12.3212 1.44861 12.3212 1.44861M0.886306 0.604417C6.06915 5.78726 1.7305 12.0393 1.7305 12.0393"
                                        stroke="#010101" stroke-width="1.37143"/>
                                </svg>
                            </span>
                        </div>
                        <div
                            class="swiper_nav_next w-[48px] h-[48px] bg-white hover:bg-primary-1 rounded-full flex items-center justify-center">
                            <span>
                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M1.08556 14.0526C1.08556 14.0526 7.35908 7.77895 14.5336 0.604417M14.5336 0.604417C9.35077 5.78726 3.09876 1.44861 3.09876 1.44861M14.5336 0.604417C9.35077 5.78726 13.6894 12.0393 13.6894 12.0393"
                                        stroke="#010101" stroke-width="1.37143"/>
                                </svg>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Feedback -->


    <!-- Platform -->
    <div class="py-12">
        <div class="container">
            <div class="flex items-center justify-between gap-4 flex-wrap">
                <div class="w-full xl:w-5/12">
                    <h2 class="text-4xl sm:text-5xl font-semibold mb-3"><?php echo e($page->data['features_title']); ?></h2>
                    <p class="text-b-color mb-8"><?php echo e($page->data['features_description']); ?></p>
                    <div class="flex flex-col gap-6">
                        <?php $__currentLoopData = $page->data['features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bg-white px-7 py-5 rounded-xl hover:shadow-default transition-all">
                                <div class="flex items-center justify-between gap-4 flex-wrap">
                                    <div class="flex items-center gap-3">
                                        <div class="shrink-0">
                                            <img src="/storage/<?php echo e($feature['icon']); ?>" alt="image" class="">
                                        </div>
                                        <div>
                                            <h6 class="text-brand-green text-base font-semibold mb-0"><?php echo e($feature['subtitle']); ?></h6>
                                            <h4 class="text-2xl font-semibold"><?php echo e($feature['title']); ?></h4>
                                        </div>
                                    </div>
                                    <span
                                        class="inline-block w-[36px] h-[36px] bg-brand-green bg-opacity-50 hover:bg-opacity-100 rounded-full flex items-center justify-center">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M0.718519 15.3351C0.718519 15.3351 7.25344 8.79999 14.7269 1.32652M14.7269 1.32652C9.32811 6.72532 2.8156 2.20588 2.8156 2.20588M14.7269 1.32652C9.32811 6.72532 13.8475 13.2378 13.8475 13.2378"
                                            stroke="white" stroke-width="1.42857"></path>
                                    </svg>
                                </span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="w-full xl:w-6/12 relative">
                    <div
                        class="w-[650px] h-[650px] absolute rounded-full border-dashed border-2 z-10 border-brand-green bg-brand-green/30">
                    </div>
                    <img src="/storage/<?php echo e($page->data['features_image']); ?>" alt="images"
                         class="relative w-[550px] z-30 mt-[50px] mr-[50px]">
                </div>
            </div>
        </div>
    </div>
    <!-- /Platform -->


    <!-- Map -->
    <div class="py-12">
        <div class="container">
            <div class="flex items-center justify-between gap-4 flex-wrap">
                <div class="w-full lg:w-6/12">
                    <div id="container-s"></div>
                </div>
                <div class="w-full lg:w-5/12">
                    <h2 class="text-4xl sm:text-5xl font-semibold mb-3 leading-[100px]"><?php echo e($page->data['map_title']); ?></h2>
                    <p class="text-b-color mb-8 "><?php echo e($page->data['map_description']); ?></p>

                    <a href="<?php echo e($page->data['map_button_url']); ?>"
                       class="px-8 py-3 rounded-full text-head-color font-medium bg-black text-white inline-flex items-center gap-2"><?php echo e($page->data['map_button_text']); ?>

                        <span><svg width="12" height="10" viewBox="0 0 12 10" fill="none"
                                   xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M0.991646 9.27349C0.991646 9.27349 6.25866 4.77968 11.0089 0.726747M11.0089 0.726747C7.57736 3.65456 3.95259 0.688952 3.95259 0.688952M11.0089 0.726747C7.57736 3.65456 9.9353 7.70104 9.9353 7.70104"
                            stroke="white" stroke-width="1.5"></path>
                        </svg>
                    </span></a>
                </div>
            </div>
        </div>
    </div>
    <!-- /Map -->


    <!-- Faq -->
    <div class="py-12">
        <div class="container">
            <div class="flex justify-center mb-9">
                <div class="lg:w-6/12">
                    <div class="text-center">
                        <h2 class="text-4xl sm:text-5xl font-semibold mb-3"><?php echo e($page->data['faq_title']); ?></h2>
                        <p><?php echo e($page->data['faq_description']); ?></p>
                    </div>
                </div>
            </div>
            <div class="flex justify-center">
                <div class="xl:w-8/12">
                    <div id="accordion-flush" data-accordion="collapse" data-active-classes="bg-white text-primary-1"
                         data-inactive-classes="text-b-color">

                        <?php $__currentLoopData = $page->data['faq']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h2 id="accordion-flush-heading-1">
                                <button type="button"
                                        class="flex items-center justify-between w-full p-5 font-medium text-gray-500 border-b border-gray-200 gap-3"
                                        data-accordion-target="#accordion-flush-body-<?php echo e($loop->index); ?>"
                                        aria-expanded="true"
                                        aria-controls="accordion-flush-body-<?php echo e($loop->index); ?>">
                                    <span><?php echo e($faq['question']); ?></span>
                                    <svg data-accordion-icon class="w-3 h-3 rotate-180 shrink-0"
                                         xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
                                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                              stroke-width="2" d="M9 5 5 1 1 5"/>
                                    </svg>
                                </button>
                            </h2>
                            <div id="accordion-flush-body-<?php echo e($loop->index); ?>" class="hidden"
                                 aria-labelledby="accordion-flush-heading-1">
                                <div class="p-5 bg-white border-b border-gray-200">
                                    <p class="text-b-color">
                                        <?php echo e($faq['answer']); ?>

                                    </p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Faq -->


    <!-- Post -->
    <div class="pt-12 pb-24">
        <div class="container">
            <div class="grid grid-cols-12 gap-4">
                <div class="col-span-12 xl:col-span-6">
                    <div class="bg-white px-7 py-9 rounded-xl group relative z-10 hover:bg-primary-2 transition-all">
                            <span class="absolute end-0 bottom-0 -z-10 group-hover:opacity-10">
                                <svg width="251" height="154" viewBox="0 0 251 154" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="161.5" cy="161" r="161" fill="#EBF9F8"/>
                                </svg>
                            </span>
                        <h5 class="text-[28px] font-semibold mb-3 group-hover:text-white"><?php echo e($page->data['cta_1_title']); ?></h5>
                        <p class="mb-6 group-hover:text-white"><?php echo e($page->data['cta_1_description']); ?></p>
                        <a href="<?php echo e($page->data['cta_1_button_link']); ?>"
                           class="px-8 py-3 rounded-full text-head-color font-medium bg-primary-1 text-white inline-flex items-center gap-2"><?php echo e($page->data['cta_1_button_text']); ?></a>
                    </div>
                </div>
                <div class="col-span-12 xl:col-span-6">
                    <div class="bg-white px-7 py-9 rounded-xl group relative z-10 hover:bg-brand-blue transition-all">
                            <span class="absolute end-0 bottom-0 -z-10 group-hover:opacity-10">
                                <svg width="251" height="154" viewBox="0 0 251 154" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="161.5" cy="161" r="161" fill="#EBF9F8"/>
                                </svg>
                            </span>
                        <h5 class="text-[28px] font-semibold mb-3 group-hover:text-white"><?php echo e($page->data['cta_2_title']); ?></h5>
                        <p class="mb-6 group-hover:text-white"><?php echo e($page->data['cta_2_description']); ?></p>
                        <a href="<?php echo e($page->data['cta_2_button_link']); ?>"
                           class="px-8 py-3 rounded-full text-head-color font-medium bg-primary-1 text-white inline-flex items-center gap-2"><?php echo e($page->data['cta_2_button_text']); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Post -->


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php /**PATH /Users/mohammedhamad/Sites/qudrat/resources/views/cms/theme/default/components/templates/home.blade.php ENDPATH**/ ?>