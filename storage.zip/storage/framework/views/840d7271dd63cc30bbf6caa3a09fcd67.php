<?php
    /** @var Track $track */
    $track = $this->track;
    
    use Illuminate\Support\Str;
    use RalphJSmit\Filament\Onboard\Step;
    use RalphJSmit\Filament\Onboard\Track;
    
    /** @var Step $currentStep */
    $currentStep = $this->currentStep;
?>

<?php if (isset($component)) { $__componentOriginalf45da69382bf4ac45a50b496dc82aa9a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf45da69382bf4ac45a50b496dc82aa9a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.simple','data' => ['class' => 'fi-rjs-onboard-page']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page.simple'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'fi-rjs-onboard-page']); ?>
     <?php $__env->slot('subheading', null, []); ?> 
        <?php if($description = $currentStep->getDescription()): ?>
            <?php echo e($description); ?>

        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if($track->getSteps()->count() > 1): ?>
            <span class="fi-rjs-onboard-step-tracker">(<?php echo e(__('filament-onboard::translations.livewire.onboard.step')); ?> <?php echo e($track->getSteps()->filter(fn(Step $step) => $step === $currentStep)->keys()->first() + 1); ?>/<?php echo e($track->getSteps()->count()); ?>)</span>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
     <?php $__env->endSlot(); ?>
    
    <!--[if BLOCK]><![endif]--><?php if($link = $currentStep->getLink()): ?>
        <div class="w-full flex items-center justify-center gap-x-4">
            <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['tag' => 'a','href' => $link,'class' => '','target' => $currentStep->shouldOpenLinkInNewTab() ? '_blank' : false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tag' => 'a','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($link),'class' => '','target' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentStep->shouldOpenLinkInNewTab() ? '_blank' : false)]); ?>
                <?php echo e($currentStep->getLinkText()); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
            
            <!--[if BLOCK]><![endif]--><?php if($currentStep->isSkippable()): ?>
                <div>
                    <?php echo e(($this->skipStepAction)(['step' => $currentStep->getIdentifier()])); ?>

                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    <?php elseif($currentStep->getWizardSteps()): ?>
        <div class="w-full">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('filament-onboard::livewire.wizard', ['stepIdentifier' => $currentStep->getIdentifier()]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1830762988-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            
            <div class="-mb-4">
            <!--[if BLOCK]><![endif]--><?php if($currentStep->isSkippable()): ?>
                <?php echo e(($this->skipStepAction)(['step' => $currentStep->getIdentifier()])); ?>

            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    <?php else: ?>
        <!--[if BLOCK]><![endif]--><?php if($this->performStepAction->isVisible()): ?>
            <div class="w-full flex items-center justify-center gap-x-4">
                <?php echo e($this->performStepAction); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf45da69382bf4ac45a50b496dc82aa9a)): ?>
<?php $attributes = $__attributesOriginalf45da69382bf4ac45a50b496dc82aa9a; ?>
<?php unset($__attributesOriginalf45da69382bf4ac45a50b496dc82aa9a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf45da69382bf4ac45a50b496dc82aa9a)): ?>
<?php $component = $__componentOriginalf45da69382bf4ac45a50b496dc82aa9a; ?>
<?php unset($__componentOriginalf45da69382bf4ac45a50b496dc82aa9a); ?>
<?php endif; ?><?php /**PATH /Users/mohammedhamad/Sites/qudrat/vendor/ralphjsmit/laravel-filament-onboard/src/../resources/views/livewire/onboard.blade.php ENDPATH**/ ?>