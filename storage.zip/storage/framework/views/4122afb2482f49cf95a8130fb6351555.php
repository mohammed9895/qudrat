<div>
    <!-- Banner -->
    <div class="bg-brand-blue/30 pt-24 md:pt-10 pb-5">
        <div class="container">
            <div class="flex items-center justify-between gap-4 flex-wrap md:flex-nowrap">
                <div class="w-full md:w-6/12">
                    <?php if (isset($component)) { $__componentOriginal2a6105802b9b852c0c1141b63006edde = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a6105802b9b852c0c1141b63006edde = $attributes; } ?>
<?php $component = WireUi\Breadcrumbs\Components\Tallstack::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Breadcrumbs\Components\Tallstack::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a6105802b9b852c0c1141b63006edde)): ?>
<?php $attributes = $__attributesOriginal2a6105802b9b852c0c1141b63006edde; ?>
<?php unset($__attributesOriginal2a6105802b9b852c0c1141b63006edde); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a6105802b9b852c0c1141b63006edde)): ?>
<?php $component = $__componentOriginal2a6105802b9b852c0c1141b63006edde; ?>
<?php unset($__componentOriginal2a6105802b9b852c0c1141b63006edde); ?>
<?php endif; ?>
                    <h2 class="text-4xl sm:text-5xl font-semibold mb-3"><?php echo e(__('general.digital-library.main-title')); ?></h2>
                </div>
                <div class="w-6/12">
                    <div class="text-end">
                        <img src="assets/images/banner_1.png" alt="images" class="hidden md:block">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Banner -->

    <!-- Card & Siderbar -->
    <div class="pt-24 pb-12">
        <div class="container">
            <div class="text-center mb-9">
                <h2 class="text-4xl sm:text-5xl font-semibold mb-3"><?php echo e(__('general.digital-library.sub-title')); ?></h2>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="">
                        <div class="bg-white p-5 rounded-xl shadow-default">
                            <img src="<?php echo e($category->getThumbnailImage()); ?>" alt="images" class="w-full mb-4 rounded-md">
                            <a href=""
                               class="inline-block text-2xl font-medium mb-3 hover:text-primary-1"><?php echo e($category->name); ?></a>
                            <p class="mb-4"><?php echo e($category->description); ?></p>
                            <a href="<?php echo e(route('digital-library.category', $category)); ?>"
                               class="inline-block px-8 py-3 rounded-full text-head-color font-medium bg-primary-1 text-white inline-flex items-center gap-2">View <?php echo e($category->posts_count); ?>

                                Resource</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>
    <!-- /Card & Siderbar -->

    <!-- Recommendation -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <!-- /Recommendation -->
</div>
<?php /**PATH /Users/mohammedhamad/Sites/qudrat/resources/views/livewire/frontend/digital-library/index.blade.php ENDPATH**/ ?>