<div>
    <!-- Banner -->
    <div class="bg-brand-blue/30 pt-24 md:pt-10 pb-5">
        <div class="container">
            <div class="flex items-center justify-between gap-4 flex-wrap md:flex-nowrap">
                <div class="w-full md:w-6/12">
                    <?php if (isset($component)) { $__componentOriginal2a6105802b9b852c0c1141b63006edde = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a6105802b9b852c0c1141b63006edde = $attributes; } ?>
<?php $component = WireUi\Breadcrumbs\Components\Tallstack::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Breadcrumbs\Components\Tallstack::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a6105802b9b852c0c1141b63006edde)): ?>
<?php $attributes = $__attributesOriginal2a6105802b9b852c0c1141b63006edde; ?>
<?php unset($__attributesOriginal2a6105802b9b852c0c1141b63006edde); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a6105802b9b852c0c1141b63006edde)): ?>
<?php $component = $__componentOriginal2a6105802b9b852c0c1141b63006edde; ?>
<?php unset($__componentOriginal2a6105802b9b852c0c1141b63006edde); ?>
<?php endif; ?>
                    <h2 class="text-4xl sm:text-5xl font-semibold mb-3"><?php echo e(__('general.digital-library.main-title')); ?></h2>
                </div>
                <div class="w-6/12">
                    <div class="text-end">
                        <img src="/assets/images/banner_1.png" alt="images" class="hidden md:block">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Banner -->

    <!-- Card & Siderbar -->
    <div class="pt-24 pb-12">
        <div class="container">
            <div class="grid grid-cols-12 gap-5">

                <div class="col-span-full md:col-span-4 xl:col-span-3">
                    <div class="bg-white p-6 rounded-xl">
                        <h6 class="text-lg font-semibold mb-3"><?php echo e(__('general.search')); ?></h6>
                        <div class="">
                            <input type="text" wire:model.live.debounce.150ms="search"
                                   class="w-full border border-gray-1 rounded-xl p-3 focus:border-[#3cc7bc] focus:ring-[#3cc7bc]"
                                   placeholder="<?php echo e(__('general.search-placeholder')); ?>">
                        </div>
                    </div>
                    <div class="bg-white p-6 rounded-xl mt-5">
                        <h6 class="text-lg font-semibold mt-3 mb-3"><?php echo e(__('general.footer.categories')); ?></h6>
                        <div class="">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center mb-4">
                                    <input id="default-checkbox" type="checkbox" value="<?php echo e($category->id); ?>"
                                           wire:model.live="categoriesList"
                                           class="peer w-4 h-4 text-primary-2 bg-white border-gray-300 rounded focus:ring-transparent focus:ring-2">
                                    <label for="default-checkbox"
                                           class="ms-2 text-sm font-medium text-b-color peer-checked:text-primary-2 w-full flex items-center">
                                        <?php echo e($category->name); ?>

                                        <span
                                            class="inline-block ms-auto">(<?php echo e($category->posts_count); ?>)</span>
                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    </div>
                </div>
                <div class="col-span-full xl:col-span-9">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="">
                                <div class="bg-white p-5 rounded-xl shadow-default">
                                    <img src="<?php echo e($post->getThumbnailImage()); ?>" alt="images"
                                         class="w-full mb-4 rounded-md">
                                    <a href=""
                                       class="inline-block text-2xl font-medium mb-3 hover:text-primary-1"><?php echo e($post->title); ?></a>
                                    <p class="mb-4"><?php echo e($post->description); ?></p>
                                    <a href="<?php echo e(route('digital-library.post', [$post->digitalLibraryCategory,$post])); ?>"
                                       class="inline-block px-8 py-3 rounded-full text-head-color font-medium bg-primary-1 text-white inline-flex items-center gap-2">View
                                        Resource</a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="mt-5">
                        <?php echo e($this->posts->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Card & Siderbar -->

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
</div>
<?php /**PATH /Users/mohammedhamad/Sites/qudrat/resources/views/livewire/frontend/digital-library/list-posts.blade.php ENDPATH**/ ?>