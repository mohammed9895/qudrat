<?php use Carbon\Carbon; ?>
<div>
    <!-- Banner -->
    <div class="bg-brand-blue/30 pt-[160px] pb-28">
        <div class="container">
            <div class="flex items-center justify-between gap-4 flex-wrap md:flex-nowrap">
                <div class="w-full md:w-6/12">
                    <?php if (isset($component)) { $__componentOriginal2a6105802b9b852c0c1141b63006edde = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a6105802b9b852c0c1141b63006edde = $attributes; } ?>
<?php $component = WireUi\Breadcrumbs\Components\Tallstack::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Breadcrumbs\Components\Tallstack::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a6105802b9b852c0c1141b63006edde)): ?>
<?php $attributes = $__attributesOriginal2a6105802b9b852c0c1141b63006edde; ?>
<?php unset($__attributesOriginal2a6105802b9b852c0c1141b63006edde); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a6105802b9b852c0c1141b63006edde)): ?>
<?php $component = $__componentOriginal2a6105802b9b852c0c1141b63006edde; ?>
<?php unset($__componentOriginal2a6105802b9b852c0c1141b63006edde); ?>
<?php endif; ?>
                    <h2 class="text-4xl sm:text-5xl font-semibold mb-3"><?php echo e(__('general.works')); ?></h2>
                </div>
                <div class="w-6/12">
                </div>
            </div>
        </div>
    </div>
    <!-- /Banner -->

    <div class="container py-24">
        <div class="grid grid-cols-4 gap-5">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white border-[3px] border-white rounded-xl p-3 relative hover:bg-white transition-all">
                    <div class="w-full mb-4">
                        <div class="rounded-md w-full h-36"
                             style="background: url('/storage/<?php echo e($work->cover); ?>'); background-size: cover; background-position: center center;"></div>
                    </div>
                    <h4 class="text-xl font-medium mb-2"><?php echo e($work->title); ?></h4>

                    <div class="flex items-center justify-start space-x-2">
                        <a href="<?php echo e(route('works.category', $work->workCategory)); ?>"
                           class="text-sm mt- mb-4 inline-flex items-center justify-center">
                            <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hugeicons-sticky-note-02'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5 mr-1 text-primary-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                            <span><?php echo e($work->workCategory->name); ?></span>
                        </a>
                        <div class="text-sm mt- mb-4 inline-flex items-center justify-center">
                            <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hugeicons-calendar-03'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5 mr-1 text-primary-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                            <span><?php echo e(Carbon::parse($work->created_at)->diffForHumans()); ?></span>
                        </div>
                    </div>
                    <!--[if BLOCK]><![endif]--><?php if($work->skills): ?>
                        <div class="flex items-center gap-1 flex-wrap mb-4">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $work->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('works.skill', $skill)); ?>"
                                   class="px-3 py-1 inline-flex border border-secondary-1 text-sm rounded-full cursor-pointer"><?php echo e($skill->name); ?></a>
                                >
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <a href="<?php echo e(route('works.show', $work)); ?>"
                       class="inline-block px-8 py-3 rounded-full border border-primary-1 text-head-color font-medium hover:bg-primary-1 hover:text-white"><?php echo e(__('general.view-work')); ?></a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

        </div>
        <div class="mt-5">
            <?php echo e($this->works->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH /Users/mohammedhamad/Sites/qudrat/resources/views/livewire/frontend/work/index.blade.php ENDPATH**/ ?>