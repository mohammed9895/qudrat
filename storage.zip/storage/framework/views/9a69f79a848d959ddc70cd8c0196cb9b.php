<?php
    /** @var Track $track */
    use RalphJSmit\Filament\Onboard\Track;
    $track = $this->track;

    $getSpanValue = function ($span): string {
        if ($span === 'full') {
            return '1 / -1';
        }

        return "span {$span} / span {$span}";
    };
?>

<div class="col-span-full fi-rjs-onboard-widget-track">
    <!--[if BLOCK]><![endif]--><?php if(!$track): ?>
        <div></div>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginalb525200bfa976483b4eaa0b7685c6e24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-widgets::components.widget','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-widgets::widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php if (isset($component)) { $__componentOriginal30dbd75eb120a380110a2b340cd88f46 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal30dbd75eb120a380110a2b340cd88f46 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.grid.index','data' => ['default' => $columnsDefault = $track->getColumns('default'),'sm' => $columnsSm = $track->getColumns('sm'),'md' => $columnsMd = $track->getColumns('md'),'lg' => $columnsLg = $track->getColumns('lg'),'xl' => $columnsXl = $track->getColumns('xl'),'twoXl' => $columnsTwoXl = $track->getColumns('2xl'),'direction' => 'row','class' => \Illuminate\Support\Arr::toCssClasses([
                    'gap-4' => ($isCompact = $track->isCompact()),
                    'gap-8' => ! $isCompact,
                ])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::grid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['default' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($columnsDefault = $track->getColumns('default')),'sm' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($columnsSm = $track->getColumns('sm')),'md' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($columnsMd = $track->getColumns('md')),'lg' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($columnsLg = $track->getColumns('lg')),'xl' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($columnsXl = $track->getColumns('xl')),'two-xl' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($columnsTwoXl = $track->getColumns('2xl')),'direction' => 'row','class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Illuminate\Support\Arr::toCssClasses([
                    'gap-4' => ($isCompact = $track->isCompact()),
                    'gap-8' => ! $isCompact,
                ]))]); ?>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $track->getSteps(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => ['class' => \Illuminate\Support\Arr::toCssClasses([
                            'relative',
                            'col-[--col-span-default]' => (bool) ($columnSpanDefault = $step->getColumnSpan('default')),
                            'sm:col-[--col-span-sm]' => (bool) ($columnSpanSm = $step->getColumnSpan('sm')),
                            'md:col-[--col-span-md]' => (bool) ($columnSpanMd = $step->getColumnSpan('md')),
                            'lg:col-[--col-span-lg]' => (bool) ($columnSpanLg= $step->getColumnSpan('lg')),
                            'xl:col-[--col-span-xl]' => (bool) ($columnSpanXl = $step->getColumnSpan('xl')),
                            '2xl:col-[--col-span-2xl]' => (bool) ($columnSpanTwoXl = $step->getColumnSpan('2xl')),
                        ]),'style' => \Illuminate\Support\Arr::toCssStyles([
                            "--col-span-default: {$getSpanValue($columnSpanDefault)}" => (bool) $columnSpanDefault,
                            "--col-span-sm: {$getSpanValue($columnSpanSm)}" => (bool) $columnSpanSm,
                            "--col-span-md: {$getSpanValue($columnSpanMd)}" => (bool) $columnSpanMd,
                            "--col-span-lg: {$getSpanValue($columnSpanLg)}" => (bool) $columnSpanLg,
                            "--col-span-xl: {$getSpanValue($columnSpanXl)}" => (bool) $columnSpanXl,
                            "--col-span-2xl: {$getSpanValue($columnSpanTwoXl)}" => (bool) $columnSpanTwoXl,
                        ])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Illuminate\Support\Arr::toCssClasses([
                            'relative',
                            'col-[--col-span-default]' => (bool) ($columnSpanDefault = $step->getColumnSpan('default')),
                            'sm:col-[--col-span-sm]' => (bool) ($columnSpanSm = $step->getColumnSpan('sm')),
                            'md:col-[--col-span-md]' => (bool) ($columnSpanMd = $step->getColumnSpan('md')),
                            'lg:col-[--col-span-lg]' => (bool) ($columnSpanLg= $step->getColumnSpan('lg')),
                            'xl:col-[--col-span-xl]' => (bool) ($columnSpanXl = $step->getColumnSpan('xl')),
                            '2xl:col-[--col-span-2xl]' => (bool) ($columnSpanTwoXl = $step->getColumnSpan('2xl')),
                        ])),'style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Illuminate\Support\Arr::toCssStyles([
                            "--col-span-default: {$getSpanValue($columnSpanDefault)}" => (bool) $columnSpanDefault,
                            "--col-span-sm: {$getSpanValue($columnSpanSm)}" => (bool) $columnSpanSm,
                            "--col-span-md: {$getSpanValue($columnSpanMd)}" => (bool) $columnSpanMd,
                            "--col-span-lg: {$getSpanValue($columnSpanLg)}" => (bool) $columnSpanLg,
                            "--col-span-xl: {$getSpanValue($columnSpanXl)}" => (bool) $columnSpanXl,
                            "--col-span-2xl: {$getSpanValue($columnSpanTwoXl)}" => (bool) $columnSpanTwoXl,
                        ]))]); ?>
                        <!--[if BLOCK]><![endif]--><?php if($icon = $step->getIcon()): ?>
                            <div
                                class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                    'rounded-full h-16 w-16 flex items-center justify-center',
                                    'bg-success-400/20' => $step->isCompleted(),
                                    'bg-custom-50 dark:bg-custom-600/25' => ! $step->isCompleted(),
                                ]); ?>"
                                style="<?php echo e(\Filament\Support\get_color_css_variables(
                                $step->getColor(),
                                shades: [50, 600],
                                alias: 'filament-onboard::widgets.track.step.background',
                            )); ?>"
                            >
                                <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['icon' => $icon,'class' => Arr::toCssClasses([
                                    'w-8 h-8 stroke-1',
                                    'text-success-600' => $step->isCompleted(),
                                    'text-custom-600 dark:text-custom-500' => ! $step->isCompleted(),
                                ]),'style' => \Filament\Support\get_color_css_variables(
                                    $step->getColor(),
                                    shades: [500, 600],
                                    alias: 'filament-onboard::widgets.track.step.icon',
                                )]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon),'class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(Arr::toCssClasses([
                                    'w-8 h-8 stroke-1',
                                    'text-success-600' => $step->isCompleted(),
                                    'text-custom-600 dark:text-custom-500' => ! $step->isCompleted(),
                                ])),'style' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Filament\Support\get_color_css_variables(
                                    $step->getColor(),
                                    shades: [500, 600],
                                    alias: 'filament-onboard::widgets.track.step.icon',
                                ))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        
                        <h2 class="mt-4 text-left text-xl font-bold tracking-tight text-gray-950 dark:text-white">
                            <?php echo e($step->getName()); ?>

                        </h2>
                        
                        <!--[if BLOCK]><![endif]--><?php if($description = $step->getDescription()): ?>
                            <div class="mt-2 text-sm text-gray-500 dark:text-gray-400 [&_*]:text-sm [&_*]:text-gray-500 dark:[&_*]:text-gray-400 prose">
                                <?php echo e($description); ?>

                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        
                        <div class="mt-4 mb-2">
                            <!--[if BLOCK]><![endif]--><?php if($step->isDone()): ?>
                                <div class="mt-0.5 inline-flex items-center space-x-1 border border-primary-600 px-1.5 py-1 rounded-full">
                                    <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['icon' => 'heroicon-o-check-circle','class' => 'w-5 h-5 stroke-1 stroke-primary-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'heroicon-o-check-circle','class' => 'w-5 h-5 stroke-1 stroke-primary-600']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
                                    <span class="text-primary-600 text-sm mr-0.5"><?php echo e(__('filament-onboard::translations.done')); ?></span>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            
                            <!--[if BLOCK]><![endif]--><?php if($step->isCurrent()): ?>
                                <?php
                                    $performStepAction = ($this->{'performStep' . $step->getIdentifier() . 'Action'})(['step' => $step->getIdentifier()]);
                                ?>
                                <!--[if BLOCK]><![endif]--><?php if($performStepAction->isVisible()): ?>
                                    <div>
                                        <?php echo e($performStepAction); ?>

                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        
                        <?php if($step->isCurrent() && $step->isSkippable()): ?>
                            <div class="absolute top-4 right-4">
                                <?php echo e(($this->skipStepAction)(['step' => $step->getIdentifier()])); ?>

                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal30dbd75eb120a380110a2b340cd88f46)): ?>
<?php $attributes = $__attributesOriginal30dbd75eb120a380110a2b340cd88f46; ?>
<?php unset($__attributesOriginal30dbd75eb120a380110a2b340cd88f46); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30dbd75eb120a380110a2b340cd88f46)): ?>
<?php $component = $__componentOriginal30dbd75eb120a380110a2b340cd88f46; ?>
<?php unset($__componentOriginal30dbd75eb120a380110a2b340cd88f46); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $attributes = $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $component = $__componentOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
        
        <?php if (isset($component)) { $__componentOriginal028e05680f6c5b1e293abd7fbe5f9758 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-actions::components.modals','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-actions::modals'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758)): ?>
<?php $attributes = $__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758; ?>
<?php unset($__attributesOriginal028e05680f6c5b1e293abd7fbe5f9758); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal028e05680f6c5b1e293abd7fbe5f9758)): ?>
<?php $component = $__componentOriginal028e05680f6c5b1e293abd7fbe5f9758; ?>
<?php unset($__componentOriginal028e05680f6c5b1e293abd7fbe5f9758); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH /Users/mohammedhamad/Sites/qudrat/vendor/ralphjsmit/laravel-filament-onboard/src/../resources/views/widgets/track.blade.php ENDPATH**/ ?>