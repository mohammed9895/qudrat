<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['layout', 'page' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['layout', 'page' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    use App\Models\JobApplication;use App\Models\Profile;use SolutionForest\FilamentCms\Dto\CmsPageData;use SolutionForest\FilamentCms\Facades\FilamentCms;

    /** @var array $layout */
    /** @var ?CmsPageData $page */

    $theme = FilamentCms::getCurrentTheme();

    $profiles_count = Profile::count();

    $experts_count = Profile::where('is_expert', 1)->count();

    $jobs_count = JobApplication::count();

?>

<?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => 'filament-cms::'.e($theme).'.page'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['layout' => $layout]); ?>
    <!-- Banner -->
    <div class="bg-brand-blue/30 pt-[160px] pb-28">
        <div class="container">
            <div class="flex items-center justify-between gap-4 flex-wrap md:flex-nowrap">
                <div class="w-full md:w-8/12">
                    <h2 class="text-4xl sm:text-5xl font-semibold mb-3"
                        style="line-height: 80px;"><?php echo e($page->data['page_title']); ?></h2>
                    <p class="mb-6 leading-relaxed"><?php echo e($page->data['page_description']); ?></p>
                </div>
                <div class="w-6/12">
                </div>
            </div>
        </div>
    </div>
    <!-- /Banner -->

    <!-- Image -->
    <div class="mt-[-60px]">
        <div class="container">
            <img src="storage/<?php echo e($page->data['page_image']); ?>" alt="image" class="w-full rounded-md">
        </div>
    </div>
    <!-- /Image -->

    <!-- Logo -->
    <div class="pt-24 pb-12">
        <div class="text-center">
            <h5 class="font-semibold text-xl mb-5"><?php echo e($page->data['sponsors_title']); ?></h5>
        </div>
        <div class="px-10">
            <div class="flex items-center justify-center 2xl:justify-between gap-5 flex-wrap">
                <?php $__currentLoopData = $page->data['sponsors_images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="/storage/<?php echo e($sponsor); ?>" alt="images"
                         class="opacity-50 hover:opacity-100 transition"/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- /Logo -->

    <!-- Tab -->
    <div class="py-12">
        <div class="container">
            <div class="flex justify-center mb-9">
                <div class="lg:w-7/12">
                    <div class="text-center">
                        <h2 class="text-4xl sm:text-5xl font-semibold"><?php echo e($page->data['about_title']); ?></h2>
                    </div>
                </div>
            </div>
            <div class="mb-4 border-b border-gray-200 dark:border-gray-700">
                <ul class="flex justify-center flex-wrap -mb-px text-sm font-medium text-center" id="default-tab"
                    role="tablist">
                    <?php $__currentLoopData = $page->data['about_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="me-2" role="presentation">
                            <button
                                class="inline-block px-4 py-2 border-b-2 rounded-t-lg text-gray-500 hover:text-gray-600 hover:border-gray-300 aria-selected:text-brand-blue aria-selected:border-brand-blue"
                                id="profile-tab"
                                data-tabs-target="#tab-<?php echo e($loop->index); ?>"
                                type="button"
                                role="tab"
                                aria-controls="tab-<?php echo e($loop->index); ?>"
                                aria-selected="<?php echo e($loop->first ? 'true' : ''); ?>"
                            >
                                <?php echo e($item['title']); ?>

                            </button>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="mt-12" id="default-tab-content">
                <?php $__currentLoopData = $page->data['about_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="<?php echo e(!$loop->first ? 'hidden' : ''); ?>" id="tab-<?php echo e($loop->index); ?>" role="tabpanel"
                         aria-labelledby="profile-tab">
                        <div class="flex items-center justify-between gap-4 flex-wrap lg:flex-nowrap">
                            <div class="w-full lg:w-5/12 rtl:order-2">
                                <h2 class="text-4xl font-semibold mb-4"><?php echo e($item['title']); ?></h2>
                                <div>
                                    <?php echo $item['description']; ?>

                                </div>
                            </div>
                            <div class="w-full lg:w-6/12 rtl:order-1">
                                <div class="flex justify-end">
                                    <img src="/storage/<?php echo e($item['image']); ?>" alt="image" class="">
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- /Tab -->

    <!-- Counter -->
    <div class="py-12">
        <div class="container">
            <div class="flex justify-center gap-4 flex-wrap md:flex-nowrap">
                <div class="w-full md:w-4/12 xl:w-3/12">
                    <div class="text-center">
                        <h2 class="text-4xl sm:text-5xl font-semibold mb-1"><?php echo e($profiles_count); ?>+</h2>
                        <h6 class="text-xl font-semibold mb-4 text-brand-red"><?php echo e(__('general.about-page.counter.profiles-count')); ?></h6>
                    </div>
                </div>
                <div class="w-full md:w-4/12 xl:w-3/12">
                    <div class="text-center">
                        <h2 class="text-4xl sm:text-5xl font-semibold mb-1"><?php echo e($experts_count); ?>+</h2>
                        <h6 class="text-xl font-semibold mb-4 text-brand-red"><?php echo e(__('general.about-page.counter.experts-count')); ?></h6>
                    </div>
                </div>
                <div class="w-full md:w-4/12 xl:w-3/12">
                    <div class="text-center">
                        <h2 class="text-4xl sm:text-5xl font-semibold mb-1"><?php echo e($jobs_count); ?>+</h2>
                        <h6 class="text-xl font-semibold mb-4 text-brand-red"><?php echo e(__('general.about-page.counter.jobs-count')); ?></h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Counter -->

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php /**PATH /Users/mohammedhamad/Sites/qudrat/resources/views/cms/theme/default/components/templates/about_page.blade.php ENDPATH**/ ?>