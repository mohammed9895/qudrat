<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['layout', 'page' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['layout', 'page' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    use App\Models\JobApplication;use App\Models\Profile;use SolutionForest\FilamentCms\Dto\CmsPageData;use SolutionForest\FilamentCms\Facades\FilamentCms;

    /** @var array $layout */
    /** @var ?CmsPageData $page */

    $theme = FilamentCms::getCurrentTheme();

    $profiles_count = Profile::count();

    $experts_count = Profile::where('is_expert', 1)->count();

    $jobs_count = JobApplication::count();

?>

<?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => 'filament-cms::'.e($theme).'.page'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['layout' => $layout]); ?>
    <!-- Banner -->
    <div class="bg-brand-blue/30 pt-[160px] pb-28">
        <div class="container">
            <div class="flex items-center justify-between gap-4 flex-wrap md:flex-nowrap">
                <div class="w-full md:w-8/12">
                    <h2 class="text-4xl sm:text-5xl font-semibold mb-3"
                        style=""><?php echo e($page->data['page_title']); ?></h2>
                    <p class="mb-6 leading-relaxed"><?php echo e($page->data['page_description']); ?></p>
                </div>
                <div class="w-6/12">
                </div>
            </div>
        </div>
    </div>
    <!-- /Banner -->

    <!-- Image -->
    <div class="mt-[-60px]">
        <div class="container">
            <img src="storage/<?php echo e($page->data['page_image']); ?>" alt="image" class="w-full rounded-md">
        </div>
    </div>
    <!-- /Image -->

    <!-- Logo -->
    <div class="pt-24 pb-12">
        <div class="text-center">
            <h5 class="font-semibold text-xl mb-5"><?php echo e($page->data['sponsors_title']); ?></h5>
        </div>
        <div class="px-10">
            <div class="flex items-center justify-center 2xl:justify-between gap-5 flex-wrap">
                <?php $__currentLoopData = $page->data['sponsors_images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="/storage/<?php echo e($sponsor); ?>" alt="images"
                         class="opacity-50 hover:opacity-100 transition"/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- /Logo -->

    <!-- Tab -->
    <div class="py-12">
        <div class="container">
            <div class="flex justify-center mb-9">
                <div class="lg:w-7/12">
                    <div class="text-center">
                        <h2 class="text-4xl sm:text-5xl font-semibold"><?php echo e($page->data['about_title']); ?></h2>
                    </div>
                </div>
            </div>
            <div class="mb-4 border-b border-gray-200 dark:border-gray-700">
                <ul class="flex justify-center flex-wrap -mb-px text-sm font-medium text-center" id="default-tab"
                    role="tablist">
                    <?php $__currentLoopData = $page->data['about_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="me-2" role="presentation">
                            <button
                                class="inline-block px-4 py-2 border-b-2 rounded-t-lg text-gray-500 hover:text-gray-600 hover:border-gray-300 aria-selected:text-brand-blue aria-selected:border-brand-blue"
                                id="profile-tab"
                                data-tabs-target="#tab-<?php echo e($loop->index); ?>"
                                type="button"
                                role="tab"
                                aria-controls="tab-<?php echo e($loop->index); ?>"
                                aria-selected="true"
                            >
                                <?php echo e($item['title']); ?>

                            </button>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="mt-12" id="default-tab-content">
                <?php $__currentLoopData = $page->data['about_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="" id="tab-<?php echo e($loop->index); ?>" role="tabpanel" aria-labelledby="profile-tab">
                        <div class="flex items-center justify-between gap-4 flex-wrap lg:flex-nowrap">
                            <div class="w-full lg:w-5/12 rtl:order-2">
                                <h2 class="text-4xl font-semibold mb-4"><?php echo e($item['title']); ?></h2>
                                <div>
                                    <?php echo $item['description']; ?>

                                </div>
                            </div>
                            <div class="w-full lg:w-6/12 rtl:order-1">
                                <div class="flex justify-end">
                                    <img src="/storage/<?php echo e($item['image']); ?>" alt="image" class="">
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- /Tab -->

    <!-- Counter -->
    <div class="py-12">
        <div class="container">
            <div class="flex justify-center gap-4 flex-wrap md:flex-nowrap">
                <div class="w-full md:w-4/12 xl:w-3/12">
                    <div class="text-center">
                        <h2 class="text-4xl sm:text-5xl font-semibold mb-1"><?php echo e($profiles_count); ?>+</h2>
                        <h6 class="text-xl font-semibold mb-4 text-brand-red"><?php echo e(__('general.about-page.counter.profiles-count')); ?></h6>
                    </div>
                </div>
                <div class="w-full md:w-4/12 xl:w-3/12">
                    <div class="text-center">
                        <h2 class="text-4xl sm:text-5xl font-semibold mb-1"><?php echo e($experts_count); ?>+</h2>
                        <h6 class="text-xl font-semibold mb-4 text-brand-red"><?php echo e(__('general.about-page.counter.experts-count')); ?></h6>
                    </div>
                </div>
                <div class="w-full md:w-4/12 xl:w-3/12">
                    <div class="text-center">
                        <h2 class="text-4xl sm:text-5xl font-semibold mb-1"><?php echo e($jobs_count); ?>+</h2>
                        <h6 class="text-xl font-semibold mb-4 text-brand-red"><?php echo e(__('general.about-page.counter.jobs-count')); ?></h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Counter -->

    <!-- Platform -->
    <div class="py-12">
        <div class="container">
            <div class="flex items-center justify-between gap-4 flex-wrap">
                <div class="w-full xl:w-5/12">
                    <h2 class="text-4xl sm:text-5xl font-semibold mb-3"><?php echo e($page->data['features_title']); ?></h2>
                    <p class="text-b-color mb-8"><?php echo e($page->data['features_description']); ?></p>
                    <div class="flex flex-col gap-6">
                        <?php $__currentLoopData = $page->data['features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bg-white px-7 py-5 rounded-xl hover:shadow-default transition-all">
                                <div class="flex items-center justify-between gap-4 flex-wrap">
                                    <div class="flex items-center gap-3">
                                        <div class="shrink-0">
                                            <img src="/storage/<?php echo e($feature['icon']); ?>" alt="image" class="">
                                        </div>
                                        <div>
                                            <h6 class="text-brand-green text-base font-semibold mb-0"><?php echo e($feature['subtitle']); ?></h6>
                                            <h4 class="text-2xl font-semibold"><?php echo e($feature['title']); ?></h4>
                                        </div>
                                    </div>
                                    <span
                                        class="inline-block w-[36px] h-[36px] bg-brand-green bg-opacity-50 hover:bg-opacity-100 rounded-full flex items-center justify-center">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M0.718519 15.3351C0.718519 15.3351 7.25344 8.79999 14.7269 1.32652M14.7269 1.32652C9.32811 6.72532 2.8156 2.20588 2.8156 2.20588M14.7269 1.32652C9.32811 6.72532 13.8475 13.2378 13.8475 13.2378"
                                            stroke="white" stroke-width="1.42857"></path>
                                    </svg>
                                </span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="w-full xl:w-6/12 relative">
                    <div
                        class="w-[650px] h-[650px] absolute rounded-full border-dashed border-2 z-10 border-brand-green bg-brand-green/30 animate-spinoo">
                    </div>
                    <img src="/storage/<?php echo e($page->data['features_image']); ?>" alt="images"
                         class="relative w-[550px] z-30 mt-[50px] mr-[50px]">
                </div>
            </div>
        </div>
    </div>
    <!-- /Platform -->

    <!-- Feedback -->
    <div class="py-12">
        <div class="container">
            <div class="rounded-lg relative">
                <img src="/storage/<?php echo e($page->data['testimonials_image']); ?>" alt="images" class="min-h-[280px] w-full">
                <div class="pt-8 sm:pt-16 lg:pt-24 w-full flex justify-center absolute start-0 top-0">
                    <div class="xl:w-7/12 text-center px-6 xl:px-0">
                        <h2 class="text-white text-4xl sm:text-5xl font-semibold mb-3"><?php echo e($page->data['testimonials_title']); ?></h2>
                    </div>
                </div>
            </div>
            <div class="sm:px-8 mt-10 lg:mt-[-70px] 2xl:mt-[-150px]">
                <div class="feedback_slider swiper pb-4">
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $page->data['testimonials']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">
                                <div class="bg-white p-7 rounded-2xl shadow-default">
                                    <p class="mb-4"><?php echo e($testimonial['description']); ?></p>
                                    <div class="flex items-center gap-4">
                                        <div class="shrink-0">
                                            <img src="/storage/<?php echo e($testimonial['image']); ?>" alt="image" class="">
                                        </div>
                                        <div>
                                            <h6 class="text-sm font-semibold"><?php echo e($testimonial['name']); ?></h6>
                                            <p class="text-xs"><?php echo e($testimonial['position']); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="flex items-center justify-center gap-4 mt-6">
                        <div
                            class="swiper_nav_prev w-[48px] h-[48px] bg-white hover:bg-primary-1 rounded-full flex items-center justify-center rtl:order-2">
                            <span>
                                <svg width="15" height="15" viewBox="0 0 15 15" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M14.3344 14.0526C14.3344 14.0526 8.06084 7.77895 0.886306 0.604417M0.886306 0.604417C6.06915 5.78726 12.3212 1.44861 12.3212 1.44861M0.886306 0.604417C6.06915 5.78726 1.7305 12.0393 1.7305 12.0393"
                                        stroke="#010101" stroke-width="1.37143"/>
                                </svg>
                            </span>
                        </div>
                        <div
                            class="swiper_nav_next w-[48px] h-[48px] bg-white hover:bg-primary-1 rounded-full flex items-center justify-center rtl:order-1">
                            <span>
                                <svg width="16" height="15" viewBox="0 0 16 15" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M1.08556 14.0526C1.08556 14.0526 7.35908 7.77895 14.5336 0.604417M14.5336 0.604417C9.35077 5.78726 3.09876 1.44861 3.09876 1.44861M14.5336 0.604417C9.35077 5.78726 13.6894 12.0393 13.6894 12.0393"
                                        stroke="#010101" stroke-width="1.37143"/>
                                </svg>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Feedback -->


    <!-- Faq -->
    <div class="py-12">
        <div class="container">
            <div class="flex justify-center mb-9">
                <div class="lg:w-6/12">
                    <div class="text-center">
                        <h2 class="text-4xl sm:text-5xl font-semibold mb-3"><?php echo e($page->data['faq_title']); ?></h2>
                        <p><?php echo e($page->data['faq_description']); ?></p>
                    </div>
                </div>
            </div>
            <div class="flex justify-center">
                <div class="xl:w-8/12">
                    <div id="accordion-flush" data-accordion="collapse" data-active-classes="bg-white text-primary-1"
                         data-inactive-classes="text-b-color">

                        <?php $__currentLoopData = $page->data['faq']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h2 id="accordion-flush-heading-1">
                                <button type="button"
                                        class="flex items-center justify-between w-full p-5 font-medium text-gray-500 border-b border-gray-200 gap-3"
                                        data-accordion-target="#accordion-flush-body-<?php echo e($loop->index); ?>"
                                        aria-expanded="true"
                                        aria-controls="accordion-flush-body-<?php echo e($loop->index); ?>">
                                    <span><?php echo e($faq['question']); ?></span>
                                    <svg data-accordion-icon class="w-3 h-3 rotate-180 shrink-0"
                                         xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
                                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                              stroke-width="2" d="M9 5 5 1 1 5"/>
                                    </svg>
                                </button>
                            </h2>
                            <div id="accordion-flush-body-<?php echo e($loop->index); ?>" class="hidden"
                                 aria-labelledby="accordion-flush-heading-1">
                                <div class="p-5 bg-white border-b border-gray-200">
                                    <p class="text-b-color">
                                        <?php echo e($faq['answer']); ?>

                                    </p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Faq -->

    <!-- Post -->
    <div class="pt-12 pb-24">
        <div class="container">
            <div class="grid grid-cols-12 gap-4">
                <div class="col-span-12 xl:col-span-6">
                    <div class="bg-white px-7 py-9 rounded-xl group relative z-10 hover:bg-primary-2 transition-all">
                            <span class="absolute end-0 bottom-0 -z-10 group-hover:opacity-10">
                                <svg width="251" height="154" viewBox="0 0 251 154" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="161.5" cy="161" r="161" fill="#EBF9F8"/>
                                </svg>
                            </span>
                        <h5 class="text-[28px] font-semibold mb-3 group-hover:text-white"><?php echo e($page->data['cta_1_title']); ?></h5>
                        <p class="mb-6 group-hover:text-white"><?php echo e($page->data['cta_1_description']); ?></p>
                        <a href="<?php echo e($page->data['cta_1_button_link']); ?>"
                           class="px-8 py-3 rounded-full text-head-color font-medium bg-primary-1 text-white inline-flex items-center gap-2"><?php echo e($page->data['cta_1_button_text']); ?></a>
                    </div>
                </div>
                <div class="col-span-12 xl:col-span-6">
                    <div class="bg-white px-7 py-9 rounded-xl group relative z-10 hover:bg-brand-blue transition-all">
                            <span class="absolute end-0 bottom-0 -z-10 group-hover:opacity-10">
                                <svg width="251" height="154" viewBox="0 0 251 154" fill="none"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="161.5" cy="161" r="161" fill="#EBF9F8"/>
                                </svg>
                            </span>
                        <h5 class="text-[28px] font-semibold mb-3 group-hover:text-white"><?php echo e($page->data['cta_2_title']); ?></h5>
                        <p class="mb-6 group-hover:text-white"><?php echo e($page->data['cta_2_description']); ?></p>
                        <a href="<?php echo e($page->data['cta_2_button_link']); ?>"
                           class="px-8 py-3 rounded-full text-head-color font-medium bg-primary-1 text-white inline-flex items-center gap-2"><?php echo e($page->data['cta_2_button_text']); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Post -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php /**PATH /Users/mohammedhamad/Sites/qudrat/resources/views/cms/theme/default/components/templates/about_page.blade.php ENDPATH**/ ?>