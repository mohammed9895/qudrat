<?php
    $state = $getState() ?? [];
?>

<!--[if BLOCK]><![endif]--><?php if(is_array($state)): ?>
    <ul>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!--[if BLOCK]><![endif]--><?php if($item['url']): ?>
                <li class="py-2">
                    <?php if (isset($component)) { $__componentOriginal549c94d872270b69c72bdf48cb183bc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal549c94d872270b69c72bdf48cb183bc9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.link','data' => ['target' => '_blank','href' => $item['url'],'icon' => $item['icon'] ?? null,'iconPosition' => $item['icon-position'] ?? 'before','style' => 'text-decoration: none;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => '_blank','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item['url']),'icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item['icon'] ?? null),'icon-position' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item['icon-position'] ?? 'before'),'style' => 'text-decoration: none;']); ?>
                        <span class="font-light text-gray-500 text-sm">
                            <?php echo e(str($item['label'])->ucfirst()); ?> |
                        </span>
                        <span class="hover:underline">
                            <?php echo e($item['url-display'] ?? $item['url']); ?>

                        </span>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $attributes = $__attributesOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $component = $__componentOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__componentOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>
                </li>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </ul>
<?php endif; ?><!--[if ENDBLOCK]><![endif]--><?php /**PATH /Users/mohammedhamad/Sites/qudrat/resources/views/vendor/filament-cms/tables/columns/cms-pages/url-column.blade.php ENDPATH**/ ?>