<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['layout' => []]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['layout' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    use SolutionForest\FilamentCms\Facades\FilamentCms;

    $layoutName = $layout['name'] ?? FilamentCms::getCurrentLayout();
    $layoutData = $layout['data'] ?? [];
?>



<?php $__env->startSection('content'); ?>
    <main <?php echo e($attributes->class([
        '',
    ])); ?>>
        <?php echo e($slot); ?>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layoutName, $layoutData, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mohammedhamad/Sites/qudrat/resources/views/vendor/filament-cms/components/default/page.blade.php ENDPATH**/ ?>